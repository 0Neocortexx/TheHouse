package com.thehouse;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ThehouseApplicationTests {

	@Test
	void contextLoads() {
	}

}
